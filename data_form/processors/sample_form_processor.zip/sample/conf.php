<?php
/* 
 * form processor config sample
 * this file sets the name of the processor and the description.
 *
 */
    $Title = 'Sample Processor';
    $Desc = 'A sample processor to learn from.';


?>
